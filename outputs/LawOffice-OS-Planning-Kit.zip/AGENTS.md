# LawOffice OS — Project instructions

- The project owner delegated planning and review to Codex and application implementation to Gemini. The current deliverable is planning documentation; its existence does not authorize deployment or use of real client data.
- Read `PRODUCT.md`, `GLOSSARY.md`, and `docs/PRD.md`, then the references for the assigned task. `GEMINI.md` governs the implementer; `docs/REVIEW_PROTOCOL.md` governs submission and review.
- Planning documents, implementation prompts, and review reports are in English. Code and domain identifiers are in English. The application remains Arabic RTL for an Egyptian law office; preserve Arabic UI examples and locale requirements. Do not reopen settled user facts.
- Each task needs a clear scope, acceptance criteria, and evidence. Review the actual implementation; do not accept another model's report without appropriate inspection.
- For future assignments, Codex selects the implementation specialist by the actual change and records why, owned paths, support reviewers, and checks. Task-level Agency routing is a default; an explicit Codex-authored slice assignment may refine it under `docs/AGENCY_AGENTS.md`. Split mixed specialties into bounded phases instead of giving every correction to the task's original lead. Implementers cannot silently substitute roles.
- Graphify is available as supplementary code navigation: follow `docs/GRAPHIFY.md` and `.agents/skills/graphify/SKILL.md`. Use local code-only committed snapshots, verify source SHAs, and inspect actual source/tests. Graph results do not replace independent review or the required native Agency children.
- Antigravity assignments live in `docs/tasks/`. Every card names exact project-local skills under `.agents/skills/`; load them and record actual paths read. See `docs/ANTIGRAVITY.md`. Skill use does not replace Codex's independent acceptance.
- Every implementation card names its required installed Agency lead/support profiles from `docs/AGENCY_AGENT_ROUTING.json`. Follow `docs/AGENCY_AGENTS.md`: the Antigravity coordinator must invoke distinct native children through `.agents/agents/`, with actual invocation IDs, ownership, checkpoint SHAs, profile paths/hashes, findings, and reconciliation. Same-session persona fallback is disabled; unavailable native execution is `BLOCKED_NATIVE_AGENTS` before dependent implementation. This is the Antigravity implementation contract; Codex retains independent planning/review. Keep project skills, approved scope/stack, and no fabricated execution or self-approval.
- Critical rules: Matter differs from Proceeding; Party roles are scoped to a matter; legal deadlines require manual review; fees, reimbursable expenses, and client advances remain separate; posted financial entries are immutable; documents are private; backups must be restorable.
- Changes to an agreed rule must explain their impact and update its source documents. Do not add SaaS, offline synchronization, or document AI to V1 tasks.
- Use synthetic test data. Never put credentials or real client documents into Git, logs, or review reports.
- Preserve owner-installed agent assets, including untracked `.agents/`, `.codex/`, and `.opencode/` files. A validator failure is not deletion authorization. Do not run cleanup/delete commands against them unless the owner explicitly assigns that exact deletion; correct validator scoping instead of removing extra profiles.
- `outputs/` contains derived reading and handoff copies. Root documents and `docs/` are the canonical sources. Regenerate deliverables whenever the plan changes to avoid conflicting versions.
- Use `https://github.com/MohamedAlksas/LawyerOS.git` as the canonical GitHub origin. Follow `docs/GIT_WORKFLOW.md`: one branch per feature/assignment, push coherent updates to its existing branch, and review through that branch's PR. Verify branch/remote/head and preserve other agents' changes. No direct-main feature pushes, force pushes, or automatic merges. Report branch/base/pushed SHA/PR URL with submissions; dependent tasks normally require accepted predecessors integrated into `origin/main`.

<!-- BEGIN:nextjs-agent-rules -->

## This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
